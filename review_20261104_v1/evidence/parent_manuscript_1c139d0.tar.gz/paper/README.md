# Manuscript

`main.tex` is the draft (reframed on 2026-10-11: the labels teach discrimination;
the gain is measured apart from calibration; the objective shapes it) and `main.pdf` is the
built article; `supplementary.tex` and `supplementary.pdf` are the supplementary
material. Every number in the tables and figures is read from `data/`, which holds
the scoring outputs, so nothing is typed in by hand and a figure cannot drift from
its table.

Build with any LaTeX toolchain that resolves the preamble; the drafts were
compiled with Tectonic:

    tectonic -X compile main.tex
    tectonic -X compile supplementary.tex

`make_figures.py` regenerates `figures/` from `data/`. The official OUP class
(`oup-authoring-template`) should replace the `article`-based preamble at
submission; the current preamble only approximates the journal's two-column
layout so the draft can be read and circulated.

## What is deliberately not in the figures

The inference-schedule sweep, which is Supplementary Section S3 (a table), and the
full learning curves; Figure 7 of the main text shows the matched-epoch validation
measures instead.

## Still to complete

- Competing interests, funding and acknowledgements are placeholders.
- `refs.bib` still holds `shin2026width` (the AlphaFold study first planned as a
  companion); it is not cited and will not be: that project was folded into this
  one (2026-10-12).
- The model-free reference (nearest training residues by local backbone) is planned
  and not yet in the paper (results/DAY_2026-10-10.md, next steps).

## Earlier drafts

Dated copies of main.tex, supplementary.tex, make_figures.py and the old figures
were removed on 2026-10-12; every one is in git history.
